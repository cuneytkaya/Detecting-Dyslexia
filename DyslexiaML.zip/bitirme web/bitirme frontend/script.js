const kamera = document.getElementById('kamera');
const kamerayiBaslatButonu = document.getElementById('kamerayi-baslat');
const kamerayiDurdurButonu = document.getElementById('kamerayi-durdur');
const gorselGonderButonu = document.getElementById('gorsel-gonder');
const cevapParagrafı = document.getElementById('cevap');

let stream;

kamerayiBaslatButonu.addEventListener('click', baslat);
kamerayiDurdurButonu.addEventListener('click', durdur);
gorselGonderButonu.addEventListener('click', gorselGonder);

function baslat() {
  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(function(mediaStream) {
        stream = mediaStream;
        kamera.srcObject = mediaStream;
        kamerayiDurdurButonu.disabled = false;
        kamerayiBaslatButonu.disabled = true;
        gorselGonderButonu.disabled = false;
      })
      .catch(function(err) {
        console.error('Kamera erişimi başarısız:', err);
        alert('Kameraya erişim izni verilmedi!');
      });
  } else {
    alert('Tarayıcınız kameraya erişimi desteklemiyor.');
  }
}

function durdur() {
  if (stream) {
    stream.getTracks().forEach(function(track) {
      track.stop();
    });
    kamerayiDurdurButonu.disabled = true;
    kamerayiBaslatButonu.disabled = false;
    gorselGonderButonu.disabled = true;
  }
}

function gorselGonder() {
  if (stream) {
    const canvas = document.createElement('canvas');
    canvas.width = kamera.videoWidth;
    canvas.height = kamera.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(kamera, 0, 0);

    const imageData = canvas.toDataURL('image/jpeg'); // Görsel verisini al
    const blob = new Blob([imageData.split(',')[1]], { type: 'image/jpeg' }); // Base64 verisini Blob'a dönüştür

    const formData = new FormData();
    formData.append('gorsel', blob, 'image.jpg'); // Dosya uzantısı ile birlikte Blob nesnesini ekle

    // **Key İsmi Değişikliği:**
    formData.append('kameraGorseli', blob, 'image.jpg'); // Key ismini "kameraGorseli" olarak değiştirin

    // **Form Data Kontrolü:**
    console.log(formData); // Form datayı konsola yazdırın

    fetch('http://127.0.0.1:5000/gorsel-kaydet', {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      body: formData
    })
      .then(function(response) {
        if (response.ok) {
          cevapParagrafı.textContent = 'Görsel başarıyla kaydedildi.';
        } else {
          response.text().then(function(text) {
            cevapParagrafı.textContent = 'Görsel kaydedilemedi: ' + text;
          });
        }
      })
      .catch(function(err) {
        console.error('Görsel gönderme hatası:', err);
        cevapParagrafı.textContent = 'Görsel gönderme hatası.';
      });
  } else {
    alert('Kamera akışı aktif değil!');
  }
}
