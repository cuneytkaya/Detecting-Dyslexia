from flask import Flask, request, make_response, jsonify
import os
import traceback
import pickle
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder
import numpy as np
import cv2
import mediapipe as mp
import csv


def faceLandmarks(fileName):
    mp_face_detection = mp.solutions.face_detection
    mp_drawing = mp.solutions.drawing_utils
    image = cv2.imread(fileName)
    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    with mp_face_detection.FaceDetection(min_detection_confidence=0.5) as face_detection:
        results = face_detection.process(rgb)

        if not results.detections:
            print("No face detected in the image.")
            return None

        csv_filename = f"{fileName.split('.')[0]}_landmarks.csv"

        with open(csv_filename, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['userName', 'date', 'Landmark Type', 'X', 'Y'])  # Örnek sütun adları

            for detection in results.detections:
                for idx, landmark in enumerate(detection.location_data.relative_keypoints):
                    writer.writerow(['dummyUser', '2023-01-01', f'Landmark {idx}', landmark.x, landmark.y])

    aiPart(csv_filename)


def aiPart(data):
    dataset = pd.read_csv(data)
    df_filtered = dataset[dataset["userName"].notna()]

    gruplu_df = df_filtered.groupby("date")

    def g(dataset):
        dataset["sıra_no"] = range(1, len(dataset) + 1)
        return dataset

    gruplu_df = gruplu_df.apply(g)

    dataset = gruplu_df.reset_index(drop=True)
    silinecek_sutunlar = ["faceTrackingHeader", "_id", "date", "_class"]
    dataset.drop(silinecek_sutunlar, axis=1, inplace=True,
                 errors='ignore')  # `errors='ignore'` ekleyerek hata almayı önleriz
    dataset["hasDyslexia"] = dataset["hasDyslexia"].replace(["Disleksi", "Evet", "Yes"], 1)
    dataset["hasDyslexia"] = dataset["hasDyslexia"].replace(["No", "Normal"], 0)
    dataset = dataset.dropna(subset=["hasDyslexia"], errors='ignore')  # `errors='ignore'` ekleyerek hata almayı önleriz
    sutunlar = ["userName", "storyTitle"]

    for sutun in sutunlar:
        if sutun in dataset.columns:
            le = LabelEncoder()
            dataset[sutun + "_kod"] = le.fit_transform(dataset[sutun])

    with open('Logistic Regression.pkl', 'rb') as file:
        logistic_regresyon = pickle.load(file)

    with open('K-Nearest Neighbors.pkl', 'rb') as file:
        knn = pickle.load(file)

    with open('Random Forest.pkl', 'rb') as file:
        random_forest = pickle.load(file)
    scaler = StandardScaler()

    X = dataset.sample(1)
    X_scaled = scaler.fit_transform(X)

    proba_lr = logistic_regresyon.predict_proba(X_scaled)[0][1]
    proba_knn = knn.predict_proba(X_scaled)[0][1]
    proba_rf = random_forest.predict_proba(X_scaled)[0][1]

    print(proba_rf, proba_lr, proba_knn)
    # return make_response(proba_rf, proba_lr, proba_knn)


image_folder = "resimler"
image_files = ["1.jpeg", "2.jpeg", "3.jpeg"]

for image_file in image_files:
    full_path = os.path.join(image_folder, image_file)
    faceLandmarks(full_path)
