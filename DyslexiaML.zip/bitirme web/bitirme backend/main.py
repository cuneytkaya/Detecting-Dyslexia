from flask import Flask, request, make_response, jsonify
import os
import traceback
import pickle
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder
import pandas as pd
import numpy as np
import cv2
import mediapipe as mp
import csv

app = Flask(__name__)

UPLOAD_FOLDER = 'resimler'

# API uç noktası
@app.route('/gorsel-kaydet', methods=['POST'])
def gorsel_kaydet():
    print(f"İstek Yöntemi: {request.method}")
    print(f"İstek URL'si: {request.url}")

    if 'gorsel' not in request.files:
        print("Hata: Görsel dosyası bulunamadı.")
        return make_response('Görsel dosyası bulunamadı.', 400)

    gorsel = request.files['gorsel']
    print(gorsel.content_type)
    dosya_adi = gorsel.filename

    try:
        gorsel.save(os.path.join(UPLOAD_FOLDER, dosya_adi))
        faceLandmarks(dosya_adi)
    except Exception as e:
        print(f"Hata: {e}")
        print(f"Hata İzi: {traceback.format_exc()}")
        return make_response('Dosya kaydedilemedi.', 500)

    print(f"Yanıt: Görsel başarıyla kaydedildi.")
    return jsonify({'mesaj': 'Görsel başarıyla kaydedildi.'})

@app.route('/gorsel-listele', methods=['GET'])
def gorsel_listele():
    return jsonify({'mesaj': 'Görseller başarıyla listelendi.'})

def faceLandmarks(fileName):
  mp_face_detection = mp.solutions.face_detection
  image = cv2.imread(fileName)
  rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
  results = mp_face_detection.detect_faces(rgb, min_detection_confidence=0.5)

  if not results.multi_face_landmarks:
    print("No face detected in the image.")
    return None

  csv_filename = f"{fileName.split('.')[0]}_landmarks.csv"

  with open(csv_filename, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Landmark Type', 'X', 'Y'])

    for face in results.multi_face_landmarks:
      for landmark in face.landmark:
        writer.writerow([landmark.type, landmark.x, landmark.y])
  aiPart(csv_filename)

def aiPart(data):
    dataset = pd.read_csv(data)
    df_filtered = dataset[dataset["userName"].notna()]

    gruplu_df = df_filtered.groupby("date")

    def g(dataset):
        dataset["sıra_no"] = range(1, len(dataset) + 1)
        return dataset

    gruplu_df = gruplu_df.apply(g)

    dataset = gruplu_df.reset_index(drop=True)
    silinecek_sutunlar = ["faceTrackingHeader", "_id", "date", "_class"]
    dataset.drop(silinecek_sutunlar, axis=1, inplace=True)
    dataset["hasDyslexia"] = dataset["hasDyslexia"].replace(["Disleksi", "Evet", "Yes"], 1)
    dataset["hasDyslexia"] = dataset["hasDyslexia"].replace(["No", "Normal"], 0)
    dataset = dataset.dropna(subset=["hasDyslexia"])
    sutunlar = ["userName", "storyTitle"]

    for sutun in sutunlar:
        le = LabelEncoder()
        dataset[sutun + "_kod"] = le.fit_transform(dataset[sutun])

    with open('Logistic Regression.pkl', 'rb') as file:
        logistic_regresyon = pickle.load(file)

    with open('K-Nearest Neighbors.pkl', 'rb') as file:
        knn = pickle.load(file)

    with open('Random Forest.pkl', 'rb') as file:
        random_forest = pickle.load(file)
    scaler = StandardScaler()

    X = dataset.sample(1)
    X_scaled = scaler.fit_transform(X)

    proba_lr = logistic_regresyon.predict_proba(X_scaled)[0][1]
    proba_knn = knn.predict_proba(X_scaled)[0][1]
    proba_rf = random_forest.predict_proba(X_scaled)[0][1]

    return make_response(proba_rf,proba_lr,proba_knn)

if __name__ == '__main__':

    app.config['CORS_ORIGINS'] = ['*']
    app.config['CORS_METHODS'] = ['POST', 'GET']
    app.config['CORS_HEADERS'] = ['Content-Type']

    app.run(debug=True)
